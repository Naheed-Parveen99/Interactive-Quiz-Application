# quiz-app
A simple quiz app built using HTML, CSS, JavaScript. <br/> 
Test your knowledge here [quiz-app](https://quizmodule-week-3-3p34g8x1a4kjuelw6w.web.codequotient.com)
